<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payhere</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="body">
        <div>
        <button class="blue-button" onclick="paymentGateway();">Payhere</button>
        </div>
    </div>
    <script src="script.js"></script>
    <script type="text/javascript" src="https://www.payhere.lk/lib/payhere.js"></script>
</body>

</html>